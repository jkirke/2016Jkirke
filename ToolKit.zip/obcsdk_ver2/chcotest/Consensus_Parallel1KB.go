package main

/******************** Testing Objective consensu:STATE TRANSFER ********
*   Setup: 4 node local docker peer network with security
*   0. Deploy chaincodeexample02 with 100000, 90000 as initial args
*   1. Send Invoke Requests on multiple peers using go routines.
*   2. Verify query results match on PEER0 and PEER1 after invoke
*********************************************************************/

import (
	"fmt"
	//"strconv"
	"time"

	"obcsdk/chaincode"
	"obcsdk/peernetwork"
	"sync"
)

func main() {

       //var argA = []string{"a"}
        //var argB = []string{"counter"}

	fmt.Println("Creating a local docker network")
	peernetwork.SetupLocalNetwork(4, true)

	_ = chaincode.InitNetwork()
	chaincode.InitChainCodes()
	chaincode.RegisterUsers()

	time.Sleep(30000 * time.Millisecond)
	//peernetwork.PrintNetworkDetails()

	data := "Yh1WWZlw1gGd2qyMNaHqBCt4zuBrnT4cvZ5iMXRRM3YBMXLZmmvyVr0ybWfiX4N3UMliEVA0d1dfTxvKs0EnHAKQe4zcoGVLzMHd8jPQlR5ww3wHeSUGOutios16lxfuQTdnsFcxhXLiGwp83ahyBomdmJ3igAYTyYw2bwXqhBeL9fa6CTK43M2QjgFhQtlcpsh7XMcUWnjJhvMHAyH67Z8Ugke6U8GQMO5aF1Oph0B2HlIQUaHMq2i6wKN8ZXyx7CCPr7lKnIVWk4zn0MLZ16LstNErrmsGeo188Rdx5Yyw04TE2OSPSsaQSDO6KrDlHYnT2DahsrY3rt3WLfBZBrUGhr9orpigPxhKq1zzXdhwKEzZ0mi6tdPqSzMKna7O9STstf2aFdrnsoovOm8SwDoOiyqfT5fc0ifVZSytVNeKE1C1eHn8FztytU2itAl1yDYSfTZQv42tnVgDjWcLe2JR1FpfexVlcB8RUhSiyoThSIFHDBZg8xyULPmp4e6acOfKfW2BXh1IDtGR87nBWqmytTOZrPoXRPq2QXiUjZS2HflHJzB0giDbWEeoZoMeF11364Xzmo0iWsBw0TQ2cHapS4cR49IoEDWkC6AJgRaNb79s6vythxX9CqfMKxIpqYAbm3UAZRS7QU7MiZu2qG3xBIEegpTrkVNneprtlgh3uTSVZ2n2JTWgexMcpPsk0ILh10157SooK2P8F5RcOVrjfFoTGF3QJTC2jhuobG3PIXs5yBHdELe5yXSEUqUm2ioOGznORmVBkkaY4lP025SG1GNPnydEV9GdnMCPbrgg91UebkiZsBMM21TZFbUqP70FDAzMWZKHDkDKCPoO7b8EPXrz3qkyaIWBymSlLt6FNPcT3NkkTfg7wl4DZYDvXA2EYu0riJvaWon12KWt9aOoXig7Jh4wiaE1BgB3j5gsqKmUZTuU9op5IXSk92EIqB2zSM9XRp9W2I0yLX1KWGVkkv2OIsdTlDKIWQS9q1W8OFKuFKxbAEaQwhc7Q5Mm"


	fmt.Println("\nPOST/Chaincode: Deploying chaincode at the beginning ....")
	dAPIArgs0 := []string{"concurrency", "init", "PEER1"}
	depArgs0 := []string{"a", data, "counter", "0"}
	chaincode.DeployOnPeer(dAPIArgs0, depArgs0)

	time.Sleep(240000 * time.Millisecond)
	fmt.Println("\nPOST/Chaincode: Querying a and b after deploy >>>>>>>>>>> ")
	qAPIArgs0 := []string{"concurrency", "query"}
	qArgsa := []string{"a"}
	qArgsb := []string{"counter"}
	A, _ := chaincode.Query(qAPIArgs0, qArgsa)
	B, _ := chaincode.Query(qAPIArgs0, qArgsb)
	myStr := fmt.Sprintf("\nA = %s B= %s", A, B)
	fmt.Println(myStr)

        defer timeTrack(time.Now(), "Testcase executiion Done")
        numReq :=1000
	go InvokeLoop(numReq, data)
	time.Sleep(time.Minute * time.Duration(10))



	fmt.Println("\nPOST/Chaincode: Querying a and b after invoke >>>>>>>>>>> ")
	qAPIArgs00 := []string{"concurrency", "query", "PEER0"}
	qAPIArgs01 := []string{"concurrency", "query", "PEER1"}
	qAPIArgs02 := []string{"concurrency", "query", "PEER2"}
	qAPIArgs03 := []string{"concurrency", "query", "PEER3"}

	res0A, _ := chaincode.QueryOnHost(qAPIArgs00, qArgsa)
	res0B, _ := chaincode.QueryOnHost(qAPIArgs00, qArgsb)

	res1A, _ := chaincode.QueryOnHost(qAPIArgs01, qArgsa)
	res1B, _ := chaincode.QueryOnHost(qAPIArgs01, qArgsb)

	res2A, _ := chaincode.QueryOnHost(qAPIArgs02, qArgsa)
	res2B, _ := chaincode.QueryOnHost(qAPIArgs02, qArgsb)

	res3A, _ := chaincode.QueryOnHost(qAPIArgs03, qArgsa)
	res3B, _ := chaincode.QueryOnHost(qAPIArgs03, qArgsb)

	fmt.Println("Results in a and b PEER0 : ", res0A, res0B)
	fmt.Println("Results in a and b PEER1 : ", res1A, res1B)
	fmt.Println("Results in a and b PEER2 : ", res2A, res2B)
	fmt.Println("Results in a and b PEER3 : ", res3A, res3B)

	ht0, _ := chaincode.GetChainHeight("PEER0")
	ht1, _ := chaincode.GetChainHeight("PEER1")
	ht2, _ := chaincode.GetChainHeight("PEER2")
	ht3, _ := chaincode.GetChainHeight("PEER3")

	fmt.Printf("ht0: %d, ht1: %d, ht2: %d, ht3: %d ", ht0, ht1, ht2, ht3)


}

func InvokeLoop(numReq int, data string) {

	var wg sync.WaitGroup

	invArgs1 := []string{"concurrency", "invoke", "PEER1"}
	iAPIArgs := []string{"a", data, "counter"}

	wg.Add(2)
	go func() {

		defer wg.Done()
		k := 1
		for k <= numReq {
		   go chaincode.InvokeOnPeer(invArgs1, iAPIArgs)
		   k++
		}
		fmt.Println("# of Req Invoked on PEER1 ", k)
	}()

	go func() {

		defer wg.Done()
		invArgs3 := []string{"concurrency", "invoke", "PEER3"}
		k := 1
		for k <= numReq {
		    go chaincode.InvokeOnPeer(invArgs3, iAPIArgs)
		    k++
		}
		fmt.Println("# of Req Invoked  on PEER3", k)
	}()

	wg.Wait()
}

func timeTrack(start time.Time, name string) {
	elapsed := time.Since(start)
	fmt.Printf("\n################# %s took %s \n", name, elapsed)
	fmt.Println("################# Execution Completed #################")
}
