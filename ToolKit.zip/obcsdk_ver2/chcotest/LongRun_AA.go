package main

import (
	"fmt"
	"time"
	"strconv"
	"github.com/hyperledger/fabric/obcsdk/chaincode"
	"github.com/hyperledger/fabric/obcsdk/peernetwork"
)

func main() {

	 	fmt.Println("Peers on network ")
 	 	peernetwork.SetupLocalNetwork(4, false)
	 	peernetwork.PrintNetworkDetails()
	 	chaincode.Init()
	 	chaincode.RegisterUsers()


    //get a URL details to get info n chainstats/transactions/blocks etc.
		aPeer, _ := peernetwork.APeer(chaincode.ThisNetwork)
		url := "http://" + aPeer.PeerDetails["ip"] + ":" + aPeer.PeerDetails["port"]

		fmt.Println("Blockchain: GET Chain  ....")
		chaincode.Chain_Stats(url)

		fmt.Println("**********************************************")
		fmt.Println("**********************************************")

    defer timeTrack(time.Now(), "Testcase executiion Done")
		go schedulerTask()
		time.Sleep(time.Minute * time.Duration(72 * 60))
}

func schedulerTask() {
	//defer timeTrack(time.Now(), "schedulerTask")
	fmt.Println("**********************************************")
	fmt.Println("**********************************************")
	dAPIArgs11 := []string{"artfun", "init"}
	depArgs10 := []string{"INITIALIZE"}
	chaincode.Deploy(dAPIArgs11, depArgs10)

	time.Sleep(time.Minute * time.Duration(2))

  i := 100
	for range time.Tick(time.Second * 10){
		//call invoke here

	 	//for  ( i < 101) {
			iAPIArgs00 := []string{"artfun", "PostUser"}
			iAPIArgs11 := []string{strconv.Itoa(i), "USER", "Ashley Hart_" + strconv.Itoa(i), "PR", "One Copley ParkwayOne Copley ParkwayOne Copley ParkwayOne Copley ParkwayOne Copley ParkwayOne Copley ParkwayOne Copley ParkwayOne Copley ParkwayOne CopleyParkwayOneCopleyParkway,216,MorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisvilleMorrisville NC27560","9198063535","admin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.comadmin@itpeople.com", "SUNTRUST", "00017102345", "0234678"}
			_, _ = chaincode.Invoke(iAPIArgs00, iAPIArgs11)

			ht0, _ := chaincode.GetChainHeight("PEER0")
			ht1, _ := chaincode.GetChainHeight("PEER1")
			ht2, _ := chaincode.GetChainHeight("PEER2")
			ht3, _ := chaincode.GetChainHeight("PEER3")

			qAPIArgs00 := []string{"artfun", "GetUser"}
			qAPIArgs11 := []string{strconv.Itoa(i), "USER"}
			_, _ = chaincode.Query(qAPIArgs00, qAPIArgs11)

			//fmt.Println("We are in loop : ", i)

			fmt.Printf("\nht0: %d, ht1: %d, ht2: %d, ht3: %d",ht0, ht1, ht2, ht3)

			i++


		 //myPrints("############# Print")
       //}
      }//for range
}

func timeTrack(start time.Time, name string) {
	elapsed := time.Since(start)
	fmt.Printf("\n################# %s took %s \n", name, elapsed)
	fmt.Println("################# Execution Completed #################")
}
