// Copyright 2016 IBM.  We need some help from legal here.
// Use of this source code is governed by some sort of IBM restriction
// license that can be found ...?

// Package peerrest provides REST API GET and POST calls for the Open BlockChain SDK.
package peerrest

const (
	weNeedHelp = "We need legal advice concerning copyrights"
)
